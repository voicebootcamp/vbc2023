<?php

declare(strict_types=1);

namespace Square\Exceptions;

interface Exception extends \Throwable
{
}
