<?php

declare(strict_types=1);

namespace Square\Models;

class MeasurementUnitGeneric
{
    /**
     * The generic unit.
     */
    public const UNIT = 'UNIT';
}
