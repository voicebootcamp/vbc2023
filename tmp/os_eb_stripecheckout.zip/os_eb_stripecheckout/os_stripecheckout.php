<?php
/**
 * @version            4.1.2
 * @package            Joomla
 * @subpackage         Event Booking
 * @author             Tuan Pham Ngoc
 * @copyright          Copyright (C) 2010 - 2022 Ossolution Team
 * @license            GNU/GPL, see LICENSE.php
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Uri\Uri;

/**
 * Stripe payment plugin for Events Booking
 *
 * @author Tuan Pham Ngoc
 *
 */
class os_stripecheckout extends RADPayment
{

	/**
	 * Constructor
	 *
	 * @param   JRegistry  $params
	 * @param   array      $config
	 */
	public function __construct($params, $config = array())
	{
		// Use sandbox API keys if available
		if (!$params->get('mode', 1))
		{
			$keys = [
				'stripe_public_key',
				'stripe_api_key',
				'endpoint_secret',
			];

			foreach ($keys as $key)
			{
				if ($params->get('sandbox_' . $key))
				{
					$params->set($key, $params->get('sandbox_' . $key));
				}
			}
		}

		parent::__construct($params, $config);
	}

	/**
	 * Process payment
	 *
	 * @param   EventbookingTableRegistrant  $row
	 * @param   array                        $data
	 */
	public function processPayment($row, $data)
	{
		$this->loadStripeLib();

		$stripeClient = $this->getStripeClient();

		$Itemid  = Factory::getApplication()->input->getInt('Itemid', 0);
		$siteUrl = Uri::root();

		if ($row->process_deposit_payment)
		{
			if (PluginHelper::isEnabled('system', 'cache'))
			{
				$returnUrl = $siteUrl . 'index.php?option=com_eventbooking&view=payment&layout=complete&Itemid=' . $Itemid . '&pt=' . time();
			}
			else
			{
				$returnUrl = $siteUrl . 'index.php?option=com_eventbooking&view=payment&layout=complete&Itemid=' . $Itemid;
			}
		}
		else
		{
			$returnUrl = $siteUrl . 'index.php?option=com_eventbooking&view=complete&Itemid=' . $Itemid;
		}

		$cancelUrl = $siteUrl . 'index.php?option=com_eventbooking&view=cancel&layout=default&id=' . $row->id . '&Itemid=' . $Itemid;

		// Meta data
		$db    = Factory::getDbo();
		$query = $db->getQuery(true)
			->select('name, title')
			->from('#__eb_fields')
			->where('is_core = 1');
		$db->setQuery($query);
		$fields = $db->loadObjectList('name');

		if ($row->first_name)
		{
			$metaData[$fields['first_name']->title] = $row->first_name;
		}

		if ($row->last_name)
		{
			$metaData[$fields['last_name']->title] = $row->last_name;
		}

		if ($row->email)
		{
			$metaData['Email']  = $row->email;
		}

		$metaData['Source'] = 'Event Booking';
		$metaData['Event']  = $data['event_title'];
		
		if ($row->user_id > 0)
		{
			$metaData['User ID'] = $row->user_id;
		}

		$metaData['Registrant ID'] = $row->id;

		try
		{
			$session = $stripeClient->checkout->sessions->create([
				'payment_method_types' => $this->params->get('payment_method_types', ['card']),
				'line_items'           => [
					[
						'name'     => $data['item_name'],
						'amount'   => 100 * round($data['amount'], 2),
						'currency' => $data['currency'],
						'quantity' => 1,
					],
				],
				'payment_intent_data'  => [
					'description' => $data['item_name'],
					'metadata'    => $metaData,
				],
				'success_url'          => $returnUrl,
				'cancel_url'           => $cancelUrl,
				'client_reference_id'  => $this->params->get('order_prefix', 'EB') . $row->id,
				'customer_email'       => $row->email,
			]);

			$this->redirectToStripe($session->id);
		}
		catch (Exception $e)
		{
			Factory::getSession()->set('omnipay_payment_error_reason', $e->getMessage());

			Factory::getApplication()->redirect(Route::_('index.php?option=com_eventbooking&view=failure&Itemid=' . $Itemid,
				false));
		}
	}

	public function verifyPayment()
	{
		if (!$this->validate())
		{
			return;
		}

		$id = $this->notificationData['id'];

		/* @var EventbookingTableRegistrant $row */
		$row = Table::getInstance('Registrant', 'EventbookingTable');

		if (!$row->load($id))
		{
			$this->logGatewayData('Invalid Record ID:' . $id);

			return false;
		}

		if ($row->published == 1 && $row->payment_status)
		{
			$this->logGatewayData('Invalid Status, already published before');

			return false;
		}

		$this->onPaymentSuccess($row, $this->notificationData['transaction_id']);
	}

	/**
	 * Refund a transaction
	 *
	 * @param   EventbookingTableRegistrant  $row
	 *
	 * @throws Exception
	 */
	public function refund($row)
	{
		$this->loadStripeLib();

		$stripeClient = $this->getStripeClient();

		try
		{
			$stripeClient->refunds->create(['charge' => $row->transaction_id]);
		}
		catch (\Stripe\Exception\ApiErrorException $e)
		{

			// Use the variable $error to save any errors
			// To be displayed to the customer later in the page
			$body  = $e->getJsonBody();
			$err   = $body['error'];
			$error = $err['message'];

			throw new Exception($error);
		}
	}

	/**
	 * Validate payment
	 *
	 * @return bool
	 * @throws \Stripe\Exception\ApiErrorException
	 * @throws \Stripe\Exception\SignatureVerificationException
	 */
	protected function validate()
	{
		$this->loadStripeLib();

		\Stripe\Stripe::setApiKey($this->params->get('stripe_api_key'));

		$endpoint_secret = $this->params->get('endpoint_secret');

		$payload    = @file_get_contents('php://input');
		$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'];
		$event      = null;

		try
		{
			$event = \Stripe\Webhook::constructEvent(
				$payload, $sig_header, $endpoint_secret
			);
		}
		catch (\UnexpectedValueException $e)
		{
			// Invalid payload
			http_response_code(400); // PHP 5.4 or greater

			return false;
		}
		catch (\Stripe\Exception\SignatureVerificationException $e)
		{
			// Invalid signature
			http_response_code(400); // PHP 5.4 or greater

			return false;
		}

		if ($event->type == 'checkout.session.completed')
		{
			$stripeClient  = $this->getStripeClient();
			$session       = $event->data->object;
			$paymentIntent = $stripeClient->paymentIntents->retrieve($session->payment_intent);

			$orderPrefix = $this->params->get('order_prefix', 'EB');

			if ($orderPrefix && strpos($session->client_reference_id, $orderPrefix) === false)
			{
				return false;
			}

			$this->notificationData['id'] = (int) substr($session->client_reference_id, strlen($orderPrefix));

			$transactionId = '';

			foreach ($paymentIntent->charges as $charge)
			{
				$transactionId = $charge->id;
			}

			$this->notificationData['transaction_id'] = $transactionId;

			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * Load Stripe library, set API Key and make the API ready to be used
	 */
	protected function loadStripeLib()
	{
		if (!class_exists('\Stripe\Stripe'))
		{
			require_once JPATH_ROOT . '/components/com_eventbooking/payments/stripecheckout/init.php';
		}
	}

	/**
	 * Redirect users to Stripe for processing payment
	 *
	 * @param $sessionId
	 */
	protected function redirectToStripe($sessionId)
	{
		Factory::getDocument()->addScript('https://js.stripe.com/v3/');

		//Get redirect heading
		$language    = Factory::getLanguage();
		$languageKey = 'EB_WAIT_' . strtoupper(substr($this->name, 3));

		if ($language->hasKey($languageKey))
		{
			$redirectHeading = Text::_($languageKey);
		}
		else
		{
			$redirectHeading = Text::sprintf('EB_REDIRECT_HEADING', $this->getTitle());
		}
		?>
		<div class="payment-heading"><?php echo $redirectHeading; ?></div>
		<script type="text/javascript">
            var stripe = Stripe('<?php echo $this->params->get('stripe_public_key'); ?>');

            stripe.redirectToCheckout({
                // Make the id field from the Checkout Session creation API response
                // available to this file, so you can provide it as parameter here
                // instead of the {{CHECKOUT_SESSION_ID}} placeholder.
                sessionId: '<?php echo $sessionId; ?>'
            }).then(function (result) {
                // If `redirectToCheckout` fails due to a browser or network
                // error, display the localized error message to your customer
                // using `result.error.message`.
                alert(result.error.message);
            });
		</script>
		<?php
	}

	/**
	 * Get Stripe Client object
	 *
	 * @return \Stripe\StripeClient
	 */
	private function getStripeClient()
	{
		return new \Stripe\StripeClient($this->params->get('stripe_api_key'));
	}
}